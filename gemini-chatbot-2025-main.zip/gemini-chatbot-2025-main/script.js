const chatBody = document.querySelector(".chat-body");
const messageInput = document.querySelector(".message-input");
const sendMessageButton = document.querySelector("#send-message");
const fileInput = document.querySelector("#file-input");
const fileUploadWrapper = document.querySelector(".file-upload-wrapper");
const fileCancelButton = document.querySelector("#file-cancel");
const chatbotToggler = document.querySelector("#chatbot-toggler");
const closeChatbot = document.querySelector("#close-chatbot");

const userData = {
    message: null,
    file: {
        data: null,
        mime_type: null
    }
}

// API 
const API_KEY = "AIzaSyC7WfhTHwnFnmGJdf0PMwXc5S5edf7yanE";
const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${API_KEY}`;

const initialInputHeight = messageInput.scrollHeight;

// Tạo phần tử tin nhắn với các lớp động và trả về nó
const createMessageElement = (content, ...classes) => {
    const div = document.createElement("div");
    div.classList.add("message", ...classes);
    div.innerHTML = content;
    return div;
}

const generateBotResponse = async (incomingMessageDiv) => {
    const messageElement = incomingMessageDiv.querySelector(".message-text");
    //Thêm tin nhắn của người dùng vào lịch sử trò chuyện
    chatHistory.push({
        role: "user",
        parts: [{text: userData.message}, ...(userData.file.data ? [{inline_data: userData.file}] : [])]
    });
    
    const requestOptions = {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            contents: chatHistory
        })
    }

    try { 
        // Lấy phản hồi của bot từ API
       const response = await fetch(API_URL, requestOptions);
       const data = await response.json();
       if(!response.ok) throw new Error(data.error.message);

       // Trích xuất và hiển thị văn bản phản hồi của bot
       const apiResponseText = data.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g, "$1").trim();
       messageElement.innerText = apiResponseText;

        //Thêm phản hồi của bot vào lịch sử trò chuyện
       chatHistory.push({
            role: "model",
            parts: [{text: apiResponseText}]
        });

    } catch (error) {
        //Xử lý lỗi trong phản hồi API
        console.log(error);
        messageElement.innerText = error.message;
        messageElement.style.color = "#ff0000";
    } finally {
        //Đặt lại dữ liệu tệp của người dùng, xóa chỉ báo và cuộn trò chuyện xuống dưới cùng
        userData.file = {};
        incomingMessageDiv.classList.remove("thinking");
        chatBody.scrollTo({top: chatBody.scrollHeight, behavior: "smooth"});
    }
}

const checkBrandinfoFAQ = (message) => {
    const lowerMsg = message.toLowerCase();

    // Xử lý câu hỏi về thời gian thực
    if (
        lowerMsg.includes("hôm nay là ngày mấy") ||
        lowerMsg.includes("hôm nay thứ mấy") ||
        lowerMsg.includes("ngày hôm nay là gì") ||
        lowerMsg.includes("ngày hiện tại") ||
        lowerMsg.includes("ngày mấy") ||
        lowerMsg.match(/\bngày\b.*\bbao nhiêu\b/)
    ) {
        const today = new Date();
        const days = ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"];
        const dayName = days[today.getDay()];
        const dateStr = `${dayName}, ngày ${today.getDate()}/${today.getMonth() + 1}/${today.getFullYear()}`;
        return `Hôm nay là ${dateStr}.`;
    }

    // Kiểm tra các FAQ khác trong dữ liệu BrandInfo (nếu có)
    for (const item of faqBrandinfo) {
        if (item.keywords.some(keyword => lowerMsg.includes(keyword))) {
            return item.answer;
        }
    }

    return null;
};


// Xử lý tin nhắn gửi đi của người dùng
const handleOutgoingMessage = (e) => {
    e.preventDefault(); 
    userData.message = messageInput.value.trim();
    messageInput.value = "";
    fileUploadWrapper.classList.remove("file-uploaded");
    messageInput.dispatchEvent(new Event("input"));

    // Tạo tin nhắn người dùng
    const messageContent = `<div class="message-text"></div>${userData.file.data ? `<img src="data:${userData.file.mime_type};base64, ${userData.file.data}" class="attachment" />` : "" }`;
    const outgoingMessageDiv = createMessageElement(messageContent, "user-message");
    outgoingMessageDiv.querySelector(".message-text").textContent = userData.message;
    chatBody.appendChild(outgoingMessageDiv);
    chatBody.scrollTo({top: chatBody.scrollHeight, behavior: "smooth"});

    // Nếu không trùng FAQ thì gọi API như bình thường
    setTimeout(() => {
        const messageContent = `<svg class="bot-avatar" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 1024 1024"><path d="..."></path></svg>
            <div class="message-text">
                <div class="thinking-indicator">
                    <div class="dot"></div>
                    <div class="dot"></div>
                    <div class="dot"></div>
                </div>
            </div>`;
        const incomingMessageDiv = createMessageElement(messageContent, "bot-message", "thinking");
        chatBody.appendChild(incomingMessageDiv);
        chatBody.scrollTo({top: chatBody.scrollHeight, behavior: "smooth"});
        generateBotResponse(incomingMessageDiv);
    }, 600);

}

messageInput.addEventListener("keydown", (e) => {
    const userMessage = e.target.value.trim();
    if (e.key === "Enter" && userMessage && !e.shiftKey && window.innerWidth > 768) {
        // e.preventDefault(); 
        handleOutgoingMessage(e); 
    } 
});

//Điều chỉnh chiều cao trường nhập liệu một cách linh hoạt
messageInput.addEventListener("input", () => {
    messageInput.style.height = `${initialInputHeight}px`;
    messageInput.style.height = `${messageInput.scrollHeight}px`;
    document.querySelector(".chat-form").style.borderRadius = messageInput.scrollHeight > initialInputHeight ? "15px" : "32px";
});

// Xử lý thay đổi đầu vào tập tin
fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    if(!file) return;

    const reader = new FileReader();

    reader.onload = (e) => {
        fileUploadWrapper.querySelector("img").src = e.target.result;
        fileUploadWrapper.classList.add("file-uploaded");
        const base64String = e.target.result.split(",")[1];

        // Lưu trữ dữ liệu tệp trong userData
        userData.file = {
            data: base64String,
            mime_type: file.type
        }
        fileInput.value = "";
    }

    reader.readAsDataURL(file);
    
});

//Hủy tải tập tin lên
fileCancelButton.addEventListener("click", () => {
    userData.file = {};
    fileUploadWrapper.classList.remove("file-uploaded");
});

const exportChatToDocx = () => {
    if (chatHistory.length <= 1) return alert("Chưa có dữ liệu trò chuyện thực tế!");

    const realMessages = chatHistory.slice(1); // Bỏ prompt
    let content = "<h2>Lịch sử trò chuyện</h2>";

    realMessages.forEach(entry => {
        const fullText = entry.parts.map(p => p.text || "[Tệp đính kèm]").join("\n");

        // Tách theo dòng
        const lines = fullText.split("\n").map(line => line.trim());

        let formatted = "";
        let inList = false;

        lines.forEach(line => {
            if (line.startsWith("* ") || line.startsWith("- ")) {
                if (!inList) {
                    formatted += "<ul>";
                    inList = true;
                }
                formatted += `<li>${line.substring(2).trim()}</li>`;
            } else if (line === "") {
                if (inList) {
                    formatted += "</ul>";
                    inList = false;
                }
                formatted += "<br>";
            } else {
                if (inList) {
                    formatted += "</ul>";
                    inList = false;
                }
                formatted += `<p>${line}</p>`;
            }
        });
        if (inList) formatted += "</ul>"; // Đóng danh sách nếu còn dang dở

        content += `<div><strong>${entry.role.toUpperCase()}:</strong>${formatted}</div><hr>`;
    });

    const blob = new Blob(
        [`<html><head><meta charset="utf-8"></head><body>${content}</body></html>`],
        { type: "application/msword" }
    );

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "lich_su_chat.doc";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
};


document.getElementById("download-history").addEventListener("click", () => {
    const format = confirm("Tải về dưới dạng Word (OK) hay Excel (Cancel)?");
    if (format) {
        exportChatToDocx();
    } else {
        exportChatToExcel();
    }
});


sendMessageButton.addEventListener("click", (e) => handleOutgoingMessage(e));
document.querySelector("#file-upload").addEventListener("click", () => fileInput.click());
chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));
closeChatbot.addEventListener("click", () => document.body.classList.remove("show-chatbot"));